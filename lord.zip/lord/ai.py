from telethon import events
import config
from utils import set_pref, get_pref, get_ai_response, track_last_messages, generate_image_polli
import os

def register(client):
    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.تشغيل الذكاء$"))
    async def ai_on(e):
        set_pref(e.sender_id, "ai_enabled", True)
        await e.edit("✅ تم التشغيل")

    @client.on(events.NewMessage(incoming=True))
    async def ai_handler(e):
        me = await client.get_me()
        if not get_pref(me.id, "ai_enabled", False): return
        if e.is_private or e.mentioned or (e.is_reply and (await e.get_reply_message()).sender_id == me.id):
            track_last_messages(me.id, e.sender_id, e.raw_text or "")
            async with client.action(e.chat_id, 'typing'):
                resp = await get_ai_response(e.raw_text, get_pref(me.id, "ai_model", "sonar"), me.id, e.sender_id)
                await e.reply(resp)
    
    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.توليد\s+(.+)$"))
    async def gen_img(e):
        await e.edit("🎨...")
        if await generate_image_polli(e.pattern_match.group(1), file_path="gen.jpg"):
            await client.send_file(e.chat_id, "gen.jpg")
            await e.delete()
            os.remove("gen.jpg")
        else: await e.edit("❌ فشل")