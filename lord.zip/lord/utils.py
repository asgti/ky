        import os
        import sys
        import json
        import asyncio
        import subprocess
        import re
        import requests
        import telethon
        from datetime import datetime
        from telethon import types
        from telethon.tl.functions.users import GetFullUserRequest
        from openai import OpenAI
        import config

        # تثبيت المكتبات
        def install_and_import(package):
            try:
                return __import__(package)
            except ImportError:
                print(f"جاري تثبيت مكتبة {package}...")
                subprocess.check_call([sys.executable, "-m", "pip", "install", package])
                return __import__(package)

        pytz = install_and_import("pytz")

        # === إدارة الملفات JSON ===
        def load_json(file_path, default):
            if os.path.exists(file_path):
                try:
                    with open(file_path, 'r', encoding='utf-8') as f: return json.load(f)
                except: pass
            return default

        def save_json(file_path, data):
            with open(file_path, 'w', encoding='utf-8') as f: json.dump(data, f, indent=2, ensure_ascii=False)

        ALL_USER_SETTINGS = load_json(config.USER_SETTINGS_FILE, {})
        GROUP_DB = load_json(config.GROUP_DATA_FILE, {})

        def get_pref(user_id, key, default_val=None):
            uid = str(user_id)
            return ALL_USER_SETTINGS.get(uid, {}).get(key, default_val)

        def set_pref(user_id, key, value):
            uid = str(user_id)
            if uid not in ALL_USER_SETTINGS: ALL_USER_SETTINGS[uid] = {}
            ALL_USER_SETTINGS[uid][key] = value
            save_json(config.USER_SETTINGS_FILE, ALL_USER_SETTINGS)

        def del_pref(user_id, key):
            uid = str(user_id)
            if uid in ALL_USER_SETTINGS and key in ALL_USER_SETTINGS[uid]:
                del ALL_USER_SETTINGS[uid][key]
                save_json(config.USER_SETTINGS_FILE, ALL_USER_SETTINGS)

        def get_group_data(chat_id):
            cid = str(chat_id)
            if cid not in GROUP_DB:
                GROUP_DB[cid] = {"lock_media": False, "lock_flood": False, "muted": [], "warns": {}}
            return GROUP_DB[cid]

        def save_group_data(): save_json(config.GROUP_DATA_FILE, GROUP_DB)
        def update_group_setting(chat_id, key, value):
            get_group_data(chat_id)
            GROUP_DB[str(chat_id)][key] = value
            save_group_data()

        def load_sessions_registry(): return load_json(config.SESSIONS_FILE, {})
        def save_sessions_registry(data): save_json(config.SESSIONS_FILE, data)

        # === دوال الوقت ===
        TIME_STYLES = {
            "1": "𝟎𝟏𝟐𝟑𝟒𝟓𝟔𝟕𝟖𝟗", "2": "𝟶𝟷𝟸𝟹𝟺𝟻𝟼𝟽𝟾𝟿", "3": "𝟢𝟣𝟤𝟥𝟦𝟧𝟨𝟩𝟪𝟫",
            "4": "𝟬𝟭𝟮𝟯𝟰𝟱𝟲𝟳𝟴𝟵", "5": "𝟶𝟷𝟸𝟹𝟺𝟻𝟼𝟽𝟾𝟿", "6": "۰۱۲۳۴۵۶۷۸۹"
        }
        def apply_style(text, style_key):
            mapping = TIME_STYLES.get(style_key, TIME_STYLES["1"])
            return text.translate(str.maketrans("0123456789", mapping))

        # === دوال الذكاء الاصطناعي ===
        def get_pplx_client(user_id=None):
            key = get_pref(user_id, "pplx_api_key") or os.getenv("PPLX_API_KEY")
            if not key or len(key.strip()) < 16: return None
            return OpenAI(api_key=key.strip(), base_url="https://api.perplexity.ai")

        def track_last_messages(owner_id, user_id, text):
            oid, uid = str(owner_id), str(user_id)
            if oid not in config.LAST_MESSAGES: config.LAST_MESSAGES[oid] = {}
            if uid not in config.LAST_MESSAGES[oid]: config.LAST_MESSAGES[oid][uid] = []
            if text.strip(): config.LAST_MESSAGES[oid][uid].append(text.strip())
            if len(config.LAST_MESSAGES[oid][uid]) > 3: config.LAST_MESSAGES[oid][uid].pop(0)

        def get_last_messages_context(owner_id, user_id):
            msgs = config.LAST_MESSAGES.get(str(owner_id), {}).get(str(user_id), [])
            if not msgs: return ""
            return f"هذا سجل آخر 3 رسائل:\n" + "\n".join([f"- {m}" for m in msgs])

        async def get_ai_response(prompt, model, owner_id=None, user_id=None):
            # (تم اختصار الكود للإيجاز، نفس المنطق الموجود بالسورس الأصلي)
            ctx = get_last_messages_context(owner_id, user_id) if owner_id and user_id else ""
            sys_prompt = f"انت مساعد بوت تيليجرام."
            style = get_pref(owner_id, "ai_style")
            if style: sys_prompt += f"\nالأسلوب: {style}"

            full_prompt = f"{ctx}\nسؤال: {prompt}" if ctx else prompt

            if model.startswith("sonar"):
                cl = get_pplx_client(owner_id)
                if not cl: return "🔑 مطلوب مفتاح API."
                try:
                    r = cl.chat.completions.create(model=model, messages=[{"role":"system","content":sys_prompt},{"role":"user","content":full_prompt}])
                    return r.choices[0].message.content
                except Exception as e: return f"خطأ: {e}"

            # Pollinations logic
            try:
                url = f"https://text.pollinations.ai/{requests.utils.quote(sys_prompt + full_prompt)}?model=openai"
                r = requests.get(url, timeout=30)
                return r.text if r.status_code == 200 else "Error"
            except Exception as e: return str(e)

        async def generate_image_polli(prompt, model="flux", file_path="img.jpg"):
            try:
                url = f"https://image.pollinations.ai/prompt/{requests.utils.quote(prompt)}?model={model}&width=1024&height=1024"
                r = requests.get(url, timeout=60)
                if r.status_code == 200:
                    with open(file_path, "wb") as f: f.write(r.content)
                    return True
            except: pass
            return False

        # === دوال الرسائل الذكية ===
        def len_utf16(text): return len(text.encode('utf-16-le')) // 2
        def extract_text_and_entities(message):
            raw = message.text or ""
            # (نفس دالة الاستخراج في السورس الأصلي)
            return raw 

        async def send_smart_message(client, chat_id, text, vars, media_path=None):
            for k, v in vars.items(): text = text.replace(f"{{{k}}}", str(v))
            try:
                if media_path and os.path.exists(media_path):
                    await client.send_file(chat_id, media_path, caption=text)
                else:
                    await client.send_message(chat_id, text)
                return True
            except: return False

        def get_uptime(start_time):
            dt = datetime.now() - start_time
            return f"{dt.days}d {dt.seconds//3600}h"

        async def get_common_vars(c, u, start_time):
            # ارجاع قاموس المتغيرات
            return {"fullname": u.first_name, "username": u.username or "None", "userid": u.id, "uptime": get_uptime(start_time)}