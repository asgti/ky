from telethon import events
import config
import asyncio

def register(client):
    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.تغير اليوت\s+(.+)$"))
    async def change_src(e):
        config.SOURCE_BOT = e.pattern_match.group(1).strip().replace("@", "")
        await e.edit(f"✅ المصدر: {config.SOURCE_BOT}")

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.(يوت|حمل)\s+(.+)$"))
    async def dl_req(e):
        q = e.pattern_match.group(2)
        await e.edit("⏳...")
        try:
            msg = await client.send_message(config.SOURCE_BOT, f"{e.pattern_match.group(1)} {q}")
            async with config.request_lock:
                config.pending_requests.append({
                    "chat_id": e.chat_id, "msg_id": e.id, "target_bot": config.SOURCE_BOT,
                    "client": client, "query": q
                })
        except Exception as err: await e.edit(f"❌ {err}")

    @client.on(events.NewMessage(incoming=True))
    async def dl_resp(e):
        if not config.pending_requests: return
        sender = await e.get_sender()
        if not sender or not sender.username: return
        # (نفس منطق الاستلام الموجود في الكود الأصلي)
        # ...