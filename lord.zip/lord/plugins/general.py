from telethon import events
import config
from utils import get_pref, set_pref, del_pref, send_smart_message, get_common_vars, extract_text_and_entities
from telethon.utils import get_extension
import os

def register(client):
    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.(?:اوامري|الاوامر)$"))
    async def h_menu(e):
        txt = get_pref(e.sender_id, "help_template", config.MENUS["main"])
        media = get_pref(e.sender_id, "media_help_path")
        await send_smart_message(client, e.chat_id, txt, {}, media)
        await e.delete()

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.م([1-8])$"))
    async def h_subs(e): await e.edit(config.MENUS[f"m{e.pattern_match.group(1)}"])

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.فحص$"))
    async def ping(e):
        start = datetime.now() # Mockup
        await e.edit("⚝")
        kv = await get_common_vars(client, await client.get_me(), start) # Fix logic in main
        txt = get_pref(e.sender_id, "ping_template", "Pong! {ping}")
        media = get_pref(e.sender_id, "media_ping_path")
        if await send_smart_message(client, e.chat_id, txt, kv, media): await e.delete()

    # (أضف هنا باقي أوامر التعيين والحذف مثل .تعيين كليشة الخ)
    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.تعيين صورة (الفحص|الاوامر)$"))
    async def set_media(e):
        target = e.pattern_match.group(1)
        r = await e.get_reply_message()
        if not r or not r.media: return await e.edit("❌ رد على ميديا")
        path = f"sessions/media_{'ping' if target=='الفحص' else 'help'}_{e.sender_id}.jpg"
        await r.download_media(file=path)
        set_pref(e.sender_id, f"media_{'ping' if target=='الفحص' else 'help'}_path", path)
        await e.edit("✅ تم التعيين")
    
    from datetime import datetime # Import needed here