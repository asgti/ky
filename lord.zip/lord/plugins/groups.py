from telethon import events
from telethon.tl.types import ChatAdminRights, ChatBannedRights, ChannelParticipantsBanned
from telethon.tl.functions.channels import EditAdminRequest, EditBannedRequest
from utils import get_group_data, update_group_setting, save_group_data

def register(client):
    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.رفع مشرف( اساسي)?$"))
    async def promote(e):
        if not e.is_group: return
        r = await e.get_reply_message()
        if not r: return
        rights = ChatAdminRights(change_info=True, post_messages=True, edit_messages=True, delete_messages=True, ban_users=True, invite_users=True, pin_messages=True, add_admins=bool(e.pattern_match.group(1)), manage_call=True, other=True)
        try:
            await client(EditAdminRequest(e.chat_id, r.sender_id, rights, rank="Admin"))
            await e.edit("✅")
        except: await e.edit("❌")

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.كتم$"))
    async def mute(e):
        if not e.is_group: return
        r = await e.get_reply_message()
        if not r: return
        d = get_group_data(e.chat_id)
        if r.sender_id not in d['muted']:
            d['muted'].append(r.sender_id)
            save_group_data()
            await e.edit("🙊")
            
    @client.on(events.NewMessage(incoming=True))
    async def enforce(e):
        if not e.is_group: return
        d = get_group_data(e.chat_id)
        if e.sender_id in d['muted']:
            await e.delete()