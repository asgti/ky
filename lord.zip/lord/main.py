#!/usr/bin/env python3
# -- coding: utf-8 --
import os
import sys
import asyncio
import importlib
from datetime import datetime
from telethon import TelegramClient, events

# استيراد ملفاتنا
import config
from utils import load_sessions_registry, install_and_import

# التأكد من المجلدات
if not os.path.exists(config.SESSIONS_DIR): os.makedirs(config.SESSIONS_DIR)

# تثبيت المكاتب الضرورية
install_and_import("requests")
install_and_import("openai")

client = TelegramClient(config.SESSION, config.API_ID, config.API_HASH)

def load_plugins(c):
    """تحميل الملفات من مجلد plugins تلقائياً"""
    path = "plugins"
    for file in os.listdir(path):
        if file.endswith(".py"):
            name = file[:-3]
            try:
                mod = importlib.import_module(f"plugins.{name}")
                if hasattr(mod, "register"):
                    mod.register(c)
                    print(f"✅ تم تحميل: {name}")
            except Exception as e:
                print(f"❌ فشل تحميل {name}: {e}")

async def main():
    print("جاري التشغيل...")
    await client.start()
    
    # التحقق من تسجيل الدخول
    if not await client.is_user_authorized():
        ph = input("رقم الهاتف: ")
        await client.send_code_request(ph)
        try: await client.sign_in(ph, input("الكود: "))
        except: await client.sign_in(password=input("التحقق بخطوتين: "))

    me = await client.get_me()
    config.ADMIN_ID = me.id
    
    # تحميل البلاجنز للحساب الأساسي
    load_plugins(client)
    
    # تحميل الجلسات الأخرى
    reg = load_sessions_registry()
    for sid, info in reg.items():
        try:
            nc = TelegramClient(info['session_file'], config.API_ID, config.API_HASH)
            await nc.start()
            if await nc.is_user_authorized():
                load_plugins(nc)
                config.active_clients[sid] = nc
                asyncio.create_task(nc.run_until_disconnected())
                print(f"✅ تم تشغيل الجلسة: {info['name']}")
        except: pass

    print(f"\n🚀 السورس يعمل بنجاح!\n👤 المالك: {me.first_name}")
    await client.run_until_disconnected()

if __name__ == '__main__':
    try: asyncio.run(main())
    except KeyboardInterrupt: pass