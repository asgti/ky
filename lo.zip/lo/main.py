#!/usr/bin/env python3
# -- coding: utf-8 --

import os
import sys
import asyncio
from datetime import datetime
from telethon import TelegramClient
import config
from config import load_sessions_registry, active_clients

# استيراد البلاغنات (Plugins)
from plugins import (
    m1_download, m2_sessions, m3_time, m4_ai, 
    m5_fun, m6_custom, m7_general, m8_groups
)

FINISH_BANNER = r"""
─────▄████▀█▄
───▄█████████████████▄
─▄█████.▼.▼.▼.▼.▼.▼▼▼▼
███████
████████▄▄▲.▲▲▲▲▲▲▲
████████████████████▀▀⠀
\033[0m
Source is up and running
Developers: --- @ky_nx
"""

async def main():
    print("Run...")
    
    # 1. إعداد العميل الرئيسي
    client = TelegramClient(os.getenv("TELETHON_SESSION") or "session", config.API_ID, config.API_HASH)
    await client.connect()

    if not await client.is_user_authorized():
        print("╔══════════════════════════════════════╗")
        print("║   🚀 نظام تنصيب البوت - المرة الأولى   ║")
        print("╚══════════════════════════════════════╝")
        ph = input("رقم الهاتف: "); await client.send_code_request(ph)
        try: await client.sign_in(phone=ph, code=input("الكود: "))
        except: await client.sign_in(password=input("كلمة السر: "))

    me = await client.get_me()
    config.ADMIN_ID = me.id
    print(FINISH_BANNER)
    print(f"✅ Admin: {me.first_name} (ID: {config.ADMIN_ID})")

    # 2. دالة تسجيل البلاغنات
    def register_all_plugins(c):
        m1_download.register(c)
        m2_sessions.register(c)
        m3_time.register(c)
        m4_ai.register(c)
        m5_fun.register(c)
        m6_custom.register(c)
        m7_general.register(c)
        m8_groups.register(c)

    # تسجيل البلاغنات للعميل الرئيسي
    register_all_plugins(client)

    # 3. تحميل الجلسات الإضافية
    reg = load_sessions_registry()
    for sid, info in reg.items():
        if info.get("expiry") and datetime.fromisoformat(info["expiry"]) < datetime.now(): continue
        try:
            nc = TelegramClient(info['session_file'], config.API_ID, config.API_HASH)
            await nc.connect()
            if await nc.is_user_authorized():
                register_all_plugins(nc)
                active_clients[sid] = nc
                asyncio.create_task(nc.run_until_disconnected())
        except: pass

    await client.run_until_disconnected()

if __name__ == '__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass