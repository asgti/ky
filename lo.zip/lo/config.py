# config.py
# -- coding: utf-8 --

import os
import sys
import asyncio
import json
import subprocess
import re
from datetime import datetime
from urllib.parse import quote, quote_plus
import requests
import pytz

# --- إصلاح مشكلة الترميز في ويندوز ---
if sys.platform.startswith('win'):
    try:
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except Exception:
        pass

# دالة تثبيت واستيراد المكتبات تلقائياً
def install_and_import(package):
    try:
        return __import__(package)
    except ImportError:
        print(f"جاري تثبيت مكتبة {package}...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", package])
        return __import__(package)

openai = install_and_import("openai")
from openai import OpenAI
import telethon
from telethon import types, functions
from telethon.tl.functions.users import GetFullUserRequest

# ================= VARIABLES =================
API_ID = 16958085
API_HASH = "47b5bb80d7dc01f2230e889866cff957"
START_TIME = datetime.now()

SESSIONS_DIR = "sessions"
SESSIONS_FILE = "sessions/registry.json"
USER_SETTINGS_FILE = "sessions/user_settings.json"
GROUP_DATA_FILE = "sessions/group_data.json"

if not os.path.exists(SESSIONS_DIR): os.makedirs(SESSIONS_DIR)

# Global State Variables
ADMIN_ID = None
active_clients = {}
active_clock_tasks = {}
request_lock = asyncio.Lock()
pending_requests = []
SOURCE_BOT = "ngd_2bot"
LAST_MESSAGES = {}
ORIGINAL_PROFILE = {}
MIMIC_LIST = {}
STORAGE_STATE = {}

# ================= DATABASE & HELPERS =================
def load_json(file_path, default):
    if os.path.exists(file_path):
        try:
            with open(file_path, 'r', encoding='utf-8') as f: return json.load(f)
        except: pass
    return default

def save_json(file_path, data):
    with open(file_path, 'w', encoding='utf-8') as f: json.dump(data, f, indent=2, ensure_ascii=False)

ALL_USER_SETTINGS = load_json(USER_SETTINGS_FILE, {})
GROUP_DB = load_json(GROUP_DATA_FILE, {})

def get_pref(user_id, key, default_val=None):
    uid = str(user_id)
    return ALL_USER_SETTINGS.get(uid, {}).get(key, default_val)

def set_pref(user_id, key, value):
    uid = str(user_id)
    if uid not in ALL_USER_SETTINGS: ALL_USER_SETTINGS[uid] = {}
    ALL_USER_SETTINGS[uid][key] = value
    save_json(USER_SETTINGS_FILE, ALL_USER_SETTINGS)

def del_pref(user_id, key):
    uid = str(user_id)
    if uid in ALL_USER_SETTINGS and key in ALL_USER_SETTINGS[uid]:
        del ALL_USER_SETTINGS[uid][key]
        save_json(USER_SETTINGS_FILE, ALL_USER_SETTINGS)

def get_group_data(chat_id):
    cid = str(chat_id)
    if cid not in GROUP_DB: GROUP_DB[cid] = {"lock_media": False, "lock_flood": False, "muted": [], "warns": {}}
    return GROUP_DB[cid]

def save_group_data(): save_json(GROUP_DATA_FILE, GROUP_DB)

def update_group_setting(chat_id, key, value):
    cid = str(chat_id)
    if cid not in GROUP_DB: get_group_data(chat_id)
    GROUP_DB[cid][key] = value
    save_group_data()

def load_sessions_registry(): return load_json(SESSIONS_FILE, {})
def save_sessions_registry(data): save_json(SESSIONS_FILE, data)

def get_uptime():
    uptime = datetime.now() - START_TIME
    days = uptime.days
    hours, remainder = divmod(uptime.seconds, 3600)
    mins, _ = divmod(remainder, 60)
    return f"{days}d {hours}h {mins}m"

# ================= FORMATTING & TIME =================
ARAB_ZONES = {
    "العراق": "Asia/Baghdad", "سوريا": "Asia/Damascus", "السعودية": "Asia/Riyadh",
    "مصر": "Africa/Cairo", "الاردن": "Asia/Amman", "الكويت": "Asia/Kuwait",
    "الامارات": "Asia/Dubai", "قطر": "Asia/Qatar", "اليمن": "Asia/Aden",
    "لبنان": "Asia/Beirut", "فلسطين": "Asia/Gaza", "السودان": "Africa/Khartoum",
    "ليبيا": "Africa/Tripoli", "تونس": "Africa/Tunis", "الجزائر": "Africa/Algiers",
    "المغرب": "Africa/Casablanca"
}

TIME_STYLES = {
    "1": "𝟎𝟏𝟐𝟑𝟒𝟓𝟔𝟕𝟖𝟗", "2": "𝟶𝟷𝟸𝟹𝟺𝟻𝟼𝟽𝟾𝟿", "3": "𝟢𝟣𝟤𝟥𝟦𝟧𝟨𝟩𝟪𝟫",
    "4": "𝟬𝟭𝟮𝟯𝟰𝟱𝟲𝟳𝟴𝟵", "5": "𝟶𝟷𝟸𝟹𝟺𝟻𝟼𝟽𝟾𝟿", "6": "۰۱۲۳۴۵۶۷۸۹",
    "7": "٠١٢٣٤٥٦٧٨٩", "8": "₀₁₂₃₄₅₆₇₈₉", "9": "⓪⓵⓶⓷⓸⓹⓺⓻⓼⓽",
    "10": "⓪①②③④⑤⑥⑦⑧⑨", "11": "𝟘𝟙𝟚𝟛𝟜𝟝𝟞𝟟𝟠𝟡", "12": "⓿❶❷❸❹❺❻❼❽❾"
}

def apply_style(text, style_key):
    mapping = TIME_STYLES.get(style_key, TIME_STYLES["1"])
    return text.translate(str.maketrans("0123456789", mapping))

# ================= SMART MESSAGE UTILS =================
def len_utf16(text):
    return len(text.encode('utf-16-le')) // 2

def extract_text_and_entities(message):
    raw_text = message.text or ""
    if not message.entities: return raw_text
    sorted_ents = sorted([e for e in message.entities if isinstance(e, types.MessageEntityCustomEmoji)], key=lambda e: e.offset, reverse=True)
    final_text = raw_text
    utf16_text = final_text.encode('utf-16-le')
    for ent in sorted_ents:
        start_byte = ent.offset * 2
        end_byte = (ent.offset + ent.length) * 2
        tag = f"⦅emoji:{ent.document_id}⦆".encode('utf-16-le')
        utf16_text = utf16_text[:start_byte] + tag + utf16_text[end_byte:]
    return utf16_text.decode('utf-16-le')

async def send_smart_message(client, chat_id, template_text, formatting_vars, media_path=None):
    filled_text = template_text
    for key, value in formatting_vars.items():
        filled_text = filled_text.replace(f"{{{key}}}", str(value))

    final_text = ""
    entities = []
    last_idx = 0
    pattern = re.compile(r"⦅emoji:(\d+)⦆")
    PLACEHOLDER = "🔻" 

    for match in pattern.finditer(filled_text):
        start_chunk = filled_text[last_idx:match.start()]
        final_text += start_chunk
        offset = len_utf16(final_text)
        length = len_utf16(PLACEHOLDER)
        emoji_id = int(match.group(1))
        entities.append(types.MessageEntityCustomEmoji(offset=offset, length=length, document_id=emoji_id))
        final_text += PLACEHOLDER
        last_idx = match.end()

    final_text += filled_text[last_idx:]
    try:
        if media_path and os.path.exists(media_path):
            await client.send_file(chat_id, media_path, caption=final_text, formatting_entities=entities)
        else:
            await client.send_message(chat_id, final_text, formatting_entities=entities, link_preview=False)
        return True
    except Exception as e:
        await client.send_message(chat_id, final_text.replace("🔻", ""))
        return False

async def get_common_vars(c, target_user):
    try:
        full = await c(GetFullUserRequest(target_user))
        me_id = (await c.get_me()).id
        rank = "مالك الحساب" if target_user.id == me_id else "عضو"
        photos = await c.get_profile_photos(target_user, limit=0)
        photo_count = photos.total if photos else 0
        end = datetime.now()
        ms = (end - START_TIME).microseconds / 1000

        return {
            "fullname": target_user.first_name + (f" {target_user.last_name}" if target_user.last_name else ""),
            "username": target_user.username if target_user.username else "لا يوجد",
            "userid": target_user.id,
            "rank": rank,
            "count": photo_count,
            "mention": target_user.first_name, 
            "bio": full.full_user.about if full.full_user.about else "لا يوجد",
            "pyver": sys.version.split()[0],
            "telver": telethon.__version__,
            "uptime": get_uptime(),
            "ping": f"{ms:.1f}ms",
            "date": datetime.now().strftime('%Y-%m-%d'),
            "owner": (await c.get_me()).first_name
        }
    except Exception as e: return {}

# ================= AI LOGIC =================
AI_MODELS_LIST = [
    "sonar", "sonar-pro", "sonar-reasoning", "sonar-reasoning-pro",
    "polli-text-default", "polli-text-mistral", "polli-text-gemma",
    "polli-image-flux", "polli-image-anime",
]

def get_pplx_client(user_id=None):
    key = None
    if user_id is not None:
        key = get_pref(user_id, "pplx_api_key", None)
    if not key:
        key = os.getenv("PPLX_API_KEY")
    if not key or len(key.strip()) < 16:
        return None
    return OpenAI(api_key=key.strip(), base_url="https://api.perplexity.ai")

def get_text_model_name_polli(internal_name: str) -> str:
    if internal_name == "polli-text-mistral": return "mistral"
    if internal_name == "polli-text-gemma": return "gemma"
    return "openai"

def get_image_model_params_polli(internal_name: str) -> dict:
    if internal_name == "polli-image-anime": return {"model": "flux", "width": 768, "height": 1024}
    if internal_name == "polli-image-flux": return {"model": "flux", "width": 1024, "height": 1024}
    return {"model": "flux", "width": 768, "height": 768}

def build_training_system_prompt(owner_id):
    base = "انت مساعد ذكاء اصطناعي يعمل داخل سورس يوزر بوت تيليجرام. تمثل صاحب الحساب في الردود."
    style = get_pref(owner_id, "ai_style", None)
    if style:
        return f"{base}\nوصف اسلوب صاحب الحساب:\n{style}\nحاول تقلده قدر الإمكان."
    return base + "\nاكتب بالعربية البسيطة وباختصار."

def track_last_messages(owner_id, user_id, text):
    oid = str(owner_id)
    uid = str(user_id)
    if oid not in LAST_MESSAGES: LAST_MESSAGES[oid] = {}
    if uid not in LAST_MESSAGES[oid]: LAST_MESSAGES[oid][uid] = []
    clean_text = text.strip()
    if clean_text:
        LAST_MESSAGES[oid][uid].append(clean_text)
    if len(LAST_MESSAGES[oid][uid]) > 3:
        LAST_MESSAGES[oid][uid].pop(0)

def get_last_messages_context(owner_id, user_id):
    oid = str(owner_id)
    uid = str(user_id)
    msgs = LAST_MESSAGES.get(oid, {}).get(uid, [])
    if not msgs: return ""
    formatted_msgs = "\n".join([f"- {m}" for m in msgs])
    return f"هذا سجل آخر 3 رسائل أرسلها هذا الشخص ({uid}) سابقاً:\n{formatted_msgs}\nاستخدم هذا السياق لفهم سؤاله الحالي فقط."

def process_thinking_output(content, need_thinking, show_thinking):
    if need_thinking:
        think_part = ""
        answer_part = content
        if "الجواب:" in content:
            parts = content.split("الجواب:", 1)
            if "التفكير:" in parts[0]:
                think_part = parts[0].split("التفكير:", 1)[-1].strip()
            answer_part = parts[1].strip()
        else:
            answer_part = content.strip()

        if show_thinking and think_part:
            quoted = "\n".join([f"> {ln}" for ln in think_part.splitlines() if ln.strip()])
            return f"{quoted}\n\n{answer_part}"
        else:
            return answer_part
    return content

async def get_ai_response(prompt: str, model: str, owner_id=None, user_id=None) -> str:
    history_context = ""
    if owner_id is not None and user_id is not None:
        history_context = get_last_messages_context(owner_id, user_id)
        
    style_prompt = build_training_system_prompt(owner_id or 0)
    
    if history_context:
        base_user_prompt = f"{history_context}\n\nسؤاله الجديد:\n{prompt}"
    else:
        base_user_prompt = prompt

    show_thinking = bool(get_pref(owner_id or 0, "ai_show_thinking", False))

    if model.startswith("sonar"):
        client_local = get_pplx_client(owner_id)
        if client_local is None: return "🔑 مطلوب مفتاح API."

        need_thinking = (model == "sonar-reasoning-pro")
        if need_thinking:
            thinking_instruction = "فكّر خطوة بخطوة، ثم ارجع النتيجة:\nالتفكير:\n...\nالجواب:\n...\n"
            full_prompt = base_user_prompt + "\n\n" + thinking_instruction
        else:
            full_prompt = base_user_prompt

        try:
            resp = client_local.chat.completions.create(
                model=model,
                messages=[{"role": "system", "content": style_prompt}, {"role": "user", "content": full_prompt}],
                max_tokens=800,
            )
        except Exception as api_err: return f"❌ خطأ Perplexity: {api_err}"

        if not resp or not getattr(resp, "choices", None): return "⚠️ استجابة فارغة."
        content = resp.choices[0].message.content
        return process_thinking_output(content, need_thinking, show_thinking)

    try:
        need_thinking = (model == "polli-text-mistral")
        full_prompt = style_prompt + "\n\n" + base_user_prompt
        if need_thinking:
            full_prompt += "\n\nفكّر خطوة بخطوة، ثم ارجع النتيجة:\nالتفكير:\n...\nالجواب:\n...\n"

        text_model = get_text_model_name_polli(model) if model.startswith("polli-text") else "openai"
        url = f"https://text.pollinations.ai/{quote_plus(full_prompt)}?model={text_model}"
        r = requests.get(url, timeout=45)
        if r.status_code != 200: return f"❌ خطأ Pollinations: {r.status_code}"
        
        return process_thinking_output(r.text.strip(), need_thinking, show_thinking)

    except Exception as e: return f"❌ فشل الاتصال: {e}"

async def generate_image_polli(prompt: str, internal_model: str, file_path: str = "polli_image.jpg") -> bool:
    try:
        from urllib.parse import quote
        params = get_image_model_params_polli(internal_model)
        enc = quote(prompt)
        url = f"https://image.pollinations.ai/prompt/{enc}"
        r = requests.get(url, params=params, timeout=60)
        if r.status_code == 200:
            with open(file_path, "wb") as f: f.write(r.content)
            return True
        return False
    except: return False