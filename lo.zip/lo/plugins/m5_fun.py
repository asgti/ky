from telethon import events, types
from telethon.tl.functions.users import GetFullUserRequest
from telethon.tl.functions.account import UpdateProfileRequest, UpdateEmojiStatusRequest
from telethon.tl.functions.photos import UploadProfilePhotoRequest, DeletePhotosRequest
import config
import os

MENU_M5 = "✦ ────『التحشيش』──── ✦\n│ `.انتحال` (رد)\n│ `.اعاده`\n│ `.تقليد` (رد)\n│ `.الغاء تقليد`"

def register(client):

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.م5$"))
    async def m5_menu(e): await e.edit(MENU_M5)

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.انتحال$"))
    async def clone_user(e):
        r = await e.get_reply_message()
        if not r: return await e.edit("❌ رد على شخص")
        u = await r.get_sender()
        await e.edit("🔄 انتحال...")
        me = await client.get_me()
        if "first_name" not in config.ORIGINAL_PROFILE:
            full = await client(GetFullUserRequest(me))
            config.ORIGINAL_PROFILE.update({"first_name": me.first_name, "last_name": me.last_name, "about": full.full_user.about, "emoji_status": me.emoji_status})
        try:
            target_full = await client(GetFullUserRequest(u))
            await client(UpdateProfileRequest(first_name=u.first_name or "", last_name=u.last_name or "", about=target_full.full_user.about or ""))
            if u.emoji_status: await client(UpdateEmojiStatusRequest(emoji_status=u.emoji_status))
            pfp = await client.download_profile_photo(u, file="clone.jpg")
            if pfp: 
                await client(UploadProfilePhotoRequest(file=await client.upload_file(pfp)))
                os.remove(pfp)
            await e.edit(f"✅ تم انتحال {u.first_name}")
        except Exception as err: await e.edit(f"❌ {err}")

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.اعاده$"))
    async def revert_user(e):
        if not config.ORIGINAL_PROFILE: return await e.edit("⚠️ لا توجد نسخة")
        await e.edit("🔄 استعادة...")
        try:
            await client(UpdateProfileRequest(first_name=config.ORIGINAL_PROFILE["first_name"], last_name=config.ORIGINAL_PROFILE["last_name"] or "", about=config.ORIGINAL_PROFILE["about"] or ""))
            emoji = config.ORIGINAL_PROFILE.get("emoji_status", types.EmojiStatusEmpty())
            await client(UpdateEmojiStatusRequest(emoji_status=emoji))
            photos = await client.get_profile_photos('me')
            if photos: await client(DeletePhotosRequest(id=[photos[0]]))
            config.ORIGINAL_PROFILE.clear()
            await e.edit("✅ تم الاستعادة")
        except: await e.edit(f"❌ خطأ")

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.تقليد$"))
    async def mimic_start(e):
        r = await e.get_reply_message()
        if not r: return
        config.MIMIC_LIST.setdefault(e.chat_id, []).append(r.sender_id)
        await e.edit("🦜 بدء التقليد")

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.الغاء تقليد$"))
    async def mimic_stop(e):
        r = await e.get_reply_message()
        if not r: return
        try: config.MIMIC_LIST[e.chat_id].remove(r.sender_id); await e.edit("✅ تم الالغاء")
        except: await e.edit("⚠️ غير مفعل")

    @client.on(events.NewMessage(incoming=True))
    async def mimic_handler(e):
        if e.chat_id in config.MIMIC_LIST and e.sender_id in config.MIMIC_LIST[e.chat_id]:
            if e.text: await e.reply(e.text)
            elif e.media: await e.reply(e.media)