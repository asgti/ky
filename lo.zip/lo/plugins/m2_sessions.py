from telethon import events, TelegramClient
from telethon.tl.functions.channels import CreateChannelRequest
import config
import os
from datetime import datetime, timedelta
import asyncio

MENU_M2 = """⟪───── التنصيب والتخزين ─────⟫
     (خاص للمالك فقط)
     ① استخرج ملف الجلسة @Vedkynx_bot
     ② رد على الملف بـ:
     │ .تنصيب       ← دائم
     │ .تنصيب تجريبي  ← 4 ساعات
     │ .جلساتي    ← عرض الجلسات
     │ .انهاء + رقم  ← حذف جلسة
     ─────────────────
     │ 📦 التخزين التلقائي
     │ .تفعيل التخزين
     │ .تعطيل التخزين
     ╰───────────────────"""

def register(client):

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.م2$"))
    async def m2_menu(e): await e.edit(MENU_M2)

    # --- التخزين ---
    @client.on(events.NewMessage(incoming=True))
    async def storage_monitor(e):
        if not e.is_private: return
        my_id = (await client.get_me()).id
        gid = config.get_pref(my_id, "storage_group_id")
        if not gid: return
        try:
            sender = await e.get_sender()
            if not sender or sender.bot: return
            sid = sender.id
            if config.STORAGE_STATE.get(my_id) != sid:
                u = f"@{sender.username}" if sender.username else "لا يوجد"
                await client.send_message(gid, f"📨 **رسالة جديدة من**:\n👤 الاسم: {sender.first_name}\n🆔 الآيدي: `{sid}`\n🔗 المعرف: {u}\n────────")
                config.STORAGE_STATE[my_id] = sid
            
            is_ttl = False
            if e.message.media and (getattr(e.message, 'ttl_seconds', None) or hasattr(e.message.media, 'ttl_seconds')): is_ttl = True
            
            if is_ttl:
                await client.send_message(gid, f"⚠️ **ميديا مؤقتة (تم السحب)**")
                fp = await e.download_media()
                await client.send_file(gid, fp, caption=e.message.text or "")
                os.remove(fp)
            else:
                try: await client.forward_messages(gid, e.message)
                except: 
                    if e.message.media:
                         fp = await e.message.download_media()
                         await client.send_file(gid, fp, caption=e.message.text or "⚠️ ميديا مقيدة")
                         os.remove(fp)
                    else: await client.send_message(gid, f"📝 {e.message.text}")
        except: pass

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.تفعيل تخزين$"))
    async def enable_storage(e):
        await e.edit("🔄 إعداد...")
        try:
            gname = f"مجموعة تخزين {e.sender_id}"
            target = None
            async for d in client.iter_dialogs():
                if d.is_group and d.name == gname: target = d; break
            if not target:
                res = await client(CreateChannelRequest(title=gname, about="Owenr @ky_nx", megagroup=True))
                target = res.chats[0]
            config.set_pref(e.sender_id, "storage_group_id", target.id)
            await e.edit(f"✅ تم التفعيل في: **{gname}**")
        except Exception as err: await e.edit(f"❌ خطأ: {err}")

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.تعطيل تخزين$"))
    async def disable_storage(e):
        config.del_pref(e.sender_id, "storage_group_id")
        await e.edit("⛔ تم التعطيل")

    # --- التنصيب ---
    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.تنصيب(?:\s+(\d+)|تجريبي)?$"))
    async def install_session(e):
        if e.sender_id != config.ADMIN_ID: return await e.edit("❌ للمالك فقط")
        r = await e.get_reply_message()
        if not r or not r.document: return await e.edit("❌ ملف؟")
        await e.edit("⏳...")
        path = await r.download_media(file=config.SESSIONS_DIR)
        try:
            nc = TelegramClient(path, config.API_ID, config.API_HASH); await nc.connect()
            if not await nc.is_user_authorized(): return await e.edit("❌ تالف")
            me = await nc.get_me(); uid = str(me.id)
            expiry = None; typ = "دائم"
            if "تجريبي" in e.text: expiry = (datetime.now()+timedelta(hours=4)).isoformat(); typ = "4h"
            elif " " in e.text:
                try: d = int(e.text.split()[-1]); expiry = (datetime.now()+timedelta(days=d)).isoformat(); typ = f"{d}d"
                except: pass
            reg = config.load_sessions_registry()
            reg[uid] = {"user_id": uid, "name": me.first_name, "username": me.username, "session_file": path, "installed_at": datetime.now().isoformat(), "expiry": expiry, "install_type": typ}
            config.save_sessions_registry(reg)
            
            # هنا نستورد الدالة ديناميكياً لتجنب مشكلة circular import
            from main import main # لا حاجة لها فعلياً لأننا سنعيد تشغيل السورس او نسجل
            # ولكن لتفعيلها فورياً:
            from plugins import m1_download, m2_sessions, m3_time, m4_ai, m5_fun, m6_custom, m7_general, m8_groups
            def reg_all(c):
                 m1_download.register(c); m2_sessions.register(c); m3_time.register(c); m4_ai.register(c)
                 m5_fun.register(c); m6_custom.register(c); m7_general.register(c); m8_groups.register(c)
            
            reg_all(nc)
            config.active_clients[uid] = nc
            asyncio.create_task(nc.run_until_disconnected())
            await e.edit(f"✅ تم: {me.first_name}")
        except Exception as err: await e.edit(f"❌ {err}")

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.جلساتي$"))
    async def list_sessions(e):
        if e.sender_id != config.ADMIN_ID: return await e.edit("❌ للمالك فقط")
        reg = config.load_sessions_registry()
        if not reg: return await e.edit("📭")
        msg = "✦ الجلسات ✦\n" + "\n".join([f"{i}. {'🟢' if k in config.active_clients else '🔴'} {v['name']}" for i, (k, v) in enumerate(reg.items(), 1)])
        await e.edit(msg)

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.انهاء\s+(\d+)$"))
    async def kill_session(e):
        if e.sender_id != config.ADMIN_ID: return await e.edit("❌ للمالك فقط")
        try:
            idx = int(e.pattern_match.group(1))
            reg = config.load_sessions_registry()
            sid = list(reg.keys())[idx-1]
            if sid in config.active_clients: await config.active_clients[sid].disconnect(); del config.active_clients[sid]
            del reg[sid]; config.save_sessions_registry(reg); await e.edit("✅")
        except: await e.edit("❌")