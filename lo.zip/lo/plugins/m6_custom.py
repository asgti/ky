from telethon import events
from telethon.utils import get_extension
import config
import os

MENU_M6 = """✦ ────『التخصيص والتعيين』──── ✦
│
│ 📝 **تخصيص الكلايش** (رد على النص)
│ .تعيين كليشة الفحص
│ .تعيين كليشة الايدي
│ .تعيين كليشة الاوامر
│
│ 🖼 **تخصيص الميديا** (رد على صورة/فيديو)
│ .تعيين صورة الفحص
│ .تعيين صورة الاوامر
│
│ 🗑 **الحذف والرجوع للافتراضي**
│ .حذف كليشة (الفحص/الايدي/الاوامر)
│ .حذف صورة (الفحص/الاوامر)
╰───────────────────"""

def register(client):

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.م6$"))
    async def m6_menu(e): await e.edit(MENU_M6)

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.تعيين كليشة (الفحص|الايدي|الاوامر)$"))
    async def set_template(e):
        target = e.pattern_match.group(1)
        r = await e.get_reply_message()
        if not r or not r.text: return await e.edit("❌ يرجى الرد على النص.")
        tagged_text = config.extract_text_and_entities(r)
        key_map = {"الفحص": "ping_template", "الايدي": "id_template", "الاوامر": "help_template"}
        config.set_pref(e.sender_id, key_map[target], tagged_text)
        await e.edit(f"✅ تم تعيين كليشة {target} الخاصة بك.")

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.حذف كليشة (الفحص|الايدي|الاوامر)$"))
    async def del_template(e):
        target = e.pattern_match.group(1)
        key_map = {"الفحص": "ping_template", "الايدي": "id_template", "الاوامر": "help_template"}
        config.del_pref(e.sender_id, key_map[target])
        await e.edit(f"🗑 تم حذف كليشة {target} والعودة للافتراضي.")

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.تعيين صورة (الفحص|الاوامر)$"))
    async def set_media(e):
        target = e.pattern_match.group(1)
        r = await e.get_reply_message()
        if not r or not r.media: return await e.edit("❌ يرجى الرد على ميديا.")
        await e.edit("📥 جاري التحميل...")
        base_name = "media_ping" if target == "الفحص" else "media_help"
        ext = get_extension(r.media) or ".jpg"
        filename = f"sessions/{base_name}_{e.sender_id}{ext}"
        if os.path.exists(filename): os.remove(filename)
        await r.download_media(file=filename)
        config.set_pref(e.sender_id, f"{base_name}_path", filename)
        await e.edit(f"✅ تم تعيين ميديا {target}.")

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.حذف صورة (الفحص|الاوامر)$"))
    async def del_media(e):
        target = e.pattern_match.group(1)
        key_path = "media_ping_path" if target == "الفحص" else "media_help_path"
        path = config.get_pref(e.sender_id, key_path)
        if path and os.path.exists(path):
            os.remove(path)
            config.del_pref(e.sender_id, key_path)
            await e.edit(f"🗑 تم حذف ميديا {target}.")
        else: await e.edit("⚠️ لا توجد ميديا معينة.")