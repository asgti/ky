from telethon import events
import config
import os

MENU_M1 = """✦ ────『اوامر اليوتيوب والترفيه』──── ✦
      │ .يوت + اسم الأغنية
      │ .حمل + رابط (تيك توك/انستا/يوتيوب)
      │ .تغير اليوت + المعرف الجديد
      ╰───────────────────"""

def register(client):
    
    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.م1$"))
    async def m1_menu(e): await e.edit(MENU_M1)

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.تغير اليوت\s+(.+)$"))
    async def change_source(e):
        new_bot = e.pattern_match.group(1).strip().replace("@", "")
        config.SOURCE_BOT = new_bot
        await e.edit(f"✅ تم تغيير بوت التحميل إلى: **@{config.SOURCE_BOT}**")

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.(يوت|حمل)\s+(.+)$"))
    async def download_req(e):
        cmd = e.pattern_match.group(1)
        query = e.pattern_match.group(2).strip()
        current_target_bot = config.SOURCE_BOT 
        await e.edit(f"حارِ البحث ⏳...")
        try:
            sent = await client.send_message(current_target_bot, f"{cmd} {query}")
            async with config.request_lock:
                config.pending_requests.append({
                    "chat_id": e.chat_id, "msg_id": e.id, 
                    "target_bot": current_target_bot, "bot_msg_id": sent.id, 
                    "client": client, "query": query
                })
        except Exception as err: await e.edit(f"❌ خطأ: {err}")

    @client.on(events.NewMessage(incoming=True))
    async def download_resp(e):
        if not config.pending_requests: return
        sender = await e.get_sender()
        if not sender or not sender.username: return
        sender_username = sender.username.lower()
        matched_req = None
        matched_index = -1
        async with config.request_lock:
            for i, req in enumerate(config.pending_requests):
                if req['client'] != client: continue
                if req['target_bot'].lower() == sender_username: matched_index = i; matched_req = req; break
        if matched_req and (e.media or "http" in e.raw_text):
            async with config.request_lock:
                if matched_index < len(config.pending_requests): config.pending_requests.pop(matched_index)
            try:
                caption = f"🎵 {matched_req['query']}" if "http" not in matched_req['query'] else ""
                await client.send_file(matched_req['chat_id'], e.media, caption=caption)
                try: (await client.get_messages(matched_req['chat_id'], ids=matched_req['msg_id'])).edit("✅ تم التحميل")
                except: pass
                await client.delete_dialog(matched_req['target_bot'], revoke=True)
            except: pass