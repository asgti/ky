from telethon import events
import config
import os
import sys

MENU_MAIN = """
✦ ────『قائمة الأومر』──── ✦
• .فحص ➪ معلومات السورس
• .م1 ➪ يوتوب وتيكتوك
• .م2 ➪ التنصيب الداخلي
• .م3 ➪ الوقت والاشكال
• .م4 ➪ الذكاء الاصطناعي (Sonar+Polli)
• .م5 ➪ الانتحال والتحشيش
• .م6 ➪ التخصيص والتعيين 
• .م7 ➪ الاوامر الرئيسية 
• .م8 ➪ اوامر المجموعه (مشرفين/حماية)"""

MENU_M7 = """✦ ────『الاوامر الرئيسية』──── ✦
               │      **اوامر التخزين**   
               │.تفعيل تخزين ➪ التخزين الذاتي
               │.تعطيل تخزين ➪ التخزين الذاتي
               │     **اوامر الايدي**
               │.ايدي ➪ معلوماتك او الشخص
               │     **اوامر الفحص**
               │.فحص ➪ معلومات السورس
               │  **اوامر اعادة تشغيل و تحديث**
               │
               │.اعاده تشغيل ➪ اعادة تشغيل سورس
               │
               ╰───────────────────
    """

def register(client):

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.(?:اوامري|الاوامر)$"))
    async def h_menu(e):
        text_to_send = config.get_pref(e.sender_id, "help_template", MENU_MAIN)
        media_path = config.get_pref(e.sender_id, "media_help_path")
        await config.send_smart_message(client, e.chat_id, text_to_send, {}, media_path)
        await e.delete()

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.م7$"))
    async def m7_menu(e): await e.edit(MENU_M7)

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.(اعاده تشغيل|إعادة تشغيل)$"))
    async def restart_script(e):
        await e.edit("🔄 **جاري إعادة تشغيل النظام...**")
        os.execl(sys.executable, sys.executable, "main.py")

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.ايدي$"))
    async def id_cmd(e):
        await e.edit("🔄...")
        r = await e.get_reply_message()
        user = await r.get_sender() if r else await client.get_me()
        try:
            kv = await config.get_common_vars(client, user)
            default_tmpl = "⋆ـ┄─┄─┄─┄─┄──┄─┄─┄┄ـ⋆\n✦╎الاسـم ⇠ {fullname}\n✦╎المعـرف ⇠ @{username}\n✦╎الايـدي ⇠ {userid}\n✦╎الرتبـــه ⇠ {rank}\n✦╎البايـو ⇠ {bio}\n⋆ـ┄─┄─┄─┄─┄──┄─┄─┄┄ـ⋆"
            tmpl = config.get_pref(e.sender_id, "id_template", default_tmpl)
            pfp = await client.download_profile_photo(user)
            await config.send_smart_message(client, e.chat_id, tmpl, kv, media_path=pfp)
            await e.delete()
            if pfp: os.remove(pfp)
        except Exception as err: await e.edit(f"❌ خطأ: {err}")

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.فحص$"))
    async def ping_cmd(e):
        await e.edit("⚝")
        me = await client.get_me()
        kv = await config.get_common_vars(client, me)
        default_tmpl = "✦━───━✦✦━───━✦\n⚝ 𝓞𝔀𝓷𝓮𝓻 ⤠ {mention}\n⚝ 𝓟𝓲𝓷𝓰 ⤠ {ping}\n⚝ 𝓓𝓪𝓽𝓮 ⤠ {date}\n✦━───━✦✦━───━✦"
        tmpl = config.get_pref(e.sender_id, "ping_template", default_tmpl)
        media_path = config.get_pref(e.sender_id, "media_ping_path")
        success = await config.send_smart_message(client, e.chat_id, tmpl, kv, media_path)
        if success: await e.delete()