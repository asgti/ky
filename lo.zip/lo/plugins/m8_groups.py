from telethon import events
from telethon.tl.functions.channels import EditAdminRequest, EditBannedRequest
from telethon.tl.types import ChatAdminRights, ChatBannedRights, ChannelParticipantsBanned
import config

MENU_M8 = """✦ ────『اوامر المجموعه』──── ✦
│ 👮 **المشرفين**
│ .رفع مشرف (رد)
│ .رفع مشرف اساسي (رد)
│
│ 🛡 **الحماية والقفل**
│ .قفل الميديا | .فتح الميديا
│ .قفل الكلايش | .فتح الكلايش
│
│ 🚫 **العقوبات**
│ .طرد (رد) | .تقييد (رد)
│ .كتم (رد) | .الغاء كتم (رد)
│ .انذار (رد) (3 انذارات = كتم تلقائي)
│
│ 🧹 **التنظيف والعرض**
│ .المكتومين
│ .مسح المطرودين | .مسح المقيدين
╰───────────────────"""

def register(client):

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.م8$"))
    async def m8_menu(e): await e.edit(MENU_M8)

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.رفع مشرف( اساسي)?$"))
    async def promote_admin(e):
        if not e.is_group: return await e.edit("❌ مجموعات فقط")
        r = await e.get_reply_message()
        if not r: return await e.edit("❌ رد على العضو")
        user = await r.get_sender()
        is_full = (e.pattern_match.group(1) is not None)
        rights = ChatAdminRights(change_info=True, post_messages=True, edit_messages=True, delete_messages=True, ban_users=True, invite_users=True, pin_messages=True, add_admins=is_full, manage_call=True, other=True)
        try:
            await client(EditAdminRequest(e.chat_id, user.id, rights, rank="Admin"))
            await e.edit(f"✅ تم رفع {user.first_name} مشرف {'(اساسي)' if is_full else ''}")
        except Exception as err: await e.edit(f"❌ خطأ: {err}")

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.(قفل|فتح) (الميديا|الكلايش)$"))
    async def lock_unlock(e):
        if not e.is_group: return await e.edit("❌ مجموعات فقط")
        act = e.pattern_match.group(1)
        typ = e.pattern_match.group(2)
        key = "lock_media" if typ == "الميديا" else "lock_flood"
        val = (act == "قفل")
        config.update_group_setting(e.chat_id, key, val)
        await e.edit(f"{'🔒' if val else '🔓'} تم {act} {typ}")

    @client.on(events.NewMessage(incoming=True))
    async def group_enforcer(e):
        if not e.is_group: return
        data = config.get_group_data(e.chat_id)
        sender = await e.get_sender()
        if not sender or sender.is_self or sender.bot: return

        if sender.id in data['muted']:
            try: await e.delete()
            except: pass
            return

        if data['lock_media'] and e.media:
            try: await e.delete()
            except: pass
            return

        if data['lock_flood'] and len(e.raw_text) > 800:
            try: await e.delete()
            except: pass
            return

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.(كتم|الغاء كتم)$"))
    async def mute_unmute(e):
        if not e.is_group: return
        r = await e.get_reply_message()
        if not r: return await e.edit("❌ رد على العضو")
        uid = r.sender_id
        act = e.pattern_match.group(1)
        data = config.get_group_data(e.chat_id)
        
        if act == "كتم":
            if uid not in data['muted']:
                data['muted'].append(uid)
                config.save_group_data()
                await e.edit(f"🙊 تم كتم العضو")
            else: await e.edit("⚠️ مكتوم بالفعل")
        else:
            if uid in data['muted']:
                data['muted'].remove(uid)
                config.save_group_data()
                await e.edit(f"🔊 تم الغاء الكتم")
            else: await e.edit("⚠️ غير مكتوم")

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.المكتومين$"))
    async def list_muted(e):
        if not e.is_group: return
        data = config.get_group_data(e.chat_id)
        if not data['muted']: return await e.edit("📭 لا يوجد مكتومين")
        await e.edit(f"🙊 **المكتومين:**\n" + "\n".join([f"`{uid}`" for uid in data['muted']]))

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.انذار$"))
    async def warn_user(e):
        if not e.is_group: return
        r = await e.get_reply_message()
        if not r: return await e.edit("❌ رد على العضو")
        uid = str(r.sender_id)
        data = config.get_group_data(e.chat_id)
        
        current = data['warns'].get(uid, 0) + 1
        data['warns'][uid] = current
        config.save_group_data()
        
        if current >= 3:
            if int(uid) not in data['muted']:
                data['muted'].append(int(uid))
                data['warns'][uid] = 0
                config.save_group_data()
                await e.edit(f"⛔ **تم كتم العضو تلقائياً** (تجاوز 3 انذارات)")
        else:
            await e.edit(f"⚠️ **تم اعطاء انذار** ({current}/3)")

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.(طرد|تقييد)$"))
    async def kick_ban(e):
        if not e.is_group: return
        r = await e.get_reply_message()
        if not r: return await e.edit("❌ رد على العضو")
        act = e.pattern_match.group(1)
        try:
            if act == "طرد":
                await client.kick_participant(e.chat_id, r.sender_id)
                await e.edit("🚪 تم طرد العضو")
            else:
                await client(EditBannedRequest(e.chat_id, r.sender_id, ChatBannedRights(until_date=None, view_messages=True)))
                await e.edit("🚫 تم تقييد العضو")
        except Exception as err: await e.edit(f"❌ خطأ صلاحيات: {err}")

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.مسح (المطرودين|المقيدين)$"))
    async def clean_list(e):
        if not e.is_group: return
        await e.edit("🔄 جاري المسح...")
        count = 0
        try:
            participants = await client.get_participants(e.chat_id, filter=ChannelParticipantsBanned)
            for p in participants:
                try:
                    await client(EditBannedRequest(e.chat_id, p.id, ChatBannedRights(until_date=None, view_messages=False)))
                    count += 1
                except: pass
            await e.edit(f"✅ تم مسح {count}")
        except Exception as err: await e.edit(f"❌ خطأ: {err}")