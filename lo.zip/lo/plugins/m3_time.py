from telethon import events
from telethon.tl.functions.account import UpdateProfileRequest
import config
import asyncio
from datetime import datetime
import pytz

MENU_M3 = "✦ ────『الوقت』──── ✦\n│ `.اسم_وقتي` + البلد\n│ `.بايو_وقتي` + البلد\n│ `.الشكل` + رقم\n│ `.ايقاف الاسم` | `.ايقاف البايو`"

async def update_name_loop(client, zone, user_id):
    try:
        me = await client.get_me()
        original_name = me.first_name.split("|")[0].strip()
        while True:
            style = config.get_pref(user_id, "time_style", "1")
            now = datetime.now(pytz.timezone(zone))
            time_str = config.apply_style(now.strftime("%H:%M"), style)
            try: await client(UpdateProfileRequest(first_name=f"{original_name} | {time_str}"))
            except: pass
            await asyncio.sleep(60 - now.second)
    except: pass

async def update_bio_loop(client, zone, user_id):
    try:
        while True:
            style = config.get_pref(user_id, "time_style", "1")
            now = datetime.now(pytz.timezone(zone))
            txt = f"{now.strftime('%A')} | {now.strftime('%I:%M %p')} | {now.strftime('%Y/%m/%d')}"
            try: await client(UpdateProfileRequest(about=config.apply_style(txt, style)))
            except: pass
            await asyncio.sleep(60 - now.second)
    except: pass

def register(client):

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.م3$"))
    async def m3_menu(e): await e.edit(MENU_M3)

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.اسم_وقتي\s+(.+)$"))
    async def clock_name(e):
        ctry = e.pattern_match.group(1).strip()
        tz = config.ARAB_ZONES.get(ctry)
        if not tz: return await e.edit("❌ بلد غير موجود")
        uid = str((await client.get_me()).id)
        if uid in config.active_clock_tasks and "name" in config.active_clock_tasks[uid]: config.active_clock_tasks[uid]["name"].cancel()
        config.active_clock_tasks.setdefault(uid, {})["name"] = asyncio.create_task(update_name_loop(client, tz, uid))
        await e.edit(f"✅ اسم وقتي: {ctry}")

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.بايو_وقتي\s+(.+)$"))
    async def clock_bio(e):
        ctry = e.pattern_match.group(1).strip()
        tz = config.ARAB_ZONES.get(ctry)
        if not tz: return await e.edit("❌ بلد غير موجود")
        uid = str((await client.get_me()).id)
        if uid in config.active_clock_tasks and "bio" in config.active_clock_tasks[uid]: config.active_clock_tasks[uid]["bio"].cancel()
        config.active_clock_tasks.setdefault(uid, {})["bio"] = asyncio.create_task(update_bio_loop(client, tz, uid))
        await e.edit(f"✅ بايو وقتي: {ctry}")

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.الشكل\s+(\d+)$"))
    async def clock_style(e):
        sty = e.pattern_match.group(1)
        if sty not in config.TIME_STYLES: return await e.edit("❌ شكل غير موجود")
        config.set_pref(e.sender_id, "time_style", sty)
        await e.edit(f"✅ تم تغيير شكل الأرقام")

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.ايقاف (الاسم|البايو)$"))
    async def clock_stop(e):
        typ = e.pattern_match.group(1)
        uid = str((await client.get_me()).id)
        key = "name" if typ == "الاسم" else "bio"
        
        if uid in config.active_clock_tasks and key in config.active_clock_tasks[uid]:
            config.active_clock_tasks[uid][key].cancel()
            del config.active_clock_tasks[uid][key]
            if typ == "الاسم":
                me = await client.get_me()
                if "|" in me.first_name:
                    await client(UpdateProfileRequest(first_name=me.first_name.split("|")[0].strip()))
            else:
                await client(UpdateProfileRequest(about=""))
            await e.edit(f"✅ تم ايقاف {typ}")
        else: await e.edit("⚠️ غير مفعل")