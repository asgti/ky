from telethon import events
import config
import os

MENU_M4 = """✦ ────『الذكاء (Sonar & Polli)』──── ✦
│ .تشغيل الذكاء | .تعطيل الذكاء
│ .مفتاح + Key (لـ Perplexity)
│ .ايقاف هنا | .تشغيل هنا
│ .عرض النماذج
│ .تبديل النموذج (sonar/polli-text/image)
│ .تدريب الذكاء + وصف اسلوبك
│ .تفكير on/off (لـ sonar-reasoning/mistral)
│ .توليد + وصف الصورة (مجاني Pollinations)
"""

def register(client):
    
    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.م4$"))
    async def m4_menu(e): await e.edit(MENU_M4)

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.مفتاح\s+(.+)$"))
    async def set_pplx_key(e):
        key = e.pattern_match.group(1).strip()
        config.set_pref(e.sender_id, "pplx_api_key", key)
        await e.edit("✅ تم حفظ مفتاح Perplexity.")

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.تدريب الذكاء\s+(.+)$"))
    async def train_ai_style(e):
        style = e.pattern_match.group(1).strip()
        config.set_pref(e.sender_id, "ai_style", style)
        await e.edit("✅ تم حفظ وصف أسلوبك.")

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.تفكير\s+(on|off)$"))
    async def toggle_thinking(e):
        mode = e.pattern_match.group(1)
        config.set_pref(e.sender_id, "ai_show_thinking", mode == "on")
        await e.edit(f"✅ تم {'تفعيل' if mode == 'on' else 'تعطيل'} إظهار التفكير.")

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.(تشغيل|تعطيل) الذكاء$"))
    async def ai_toggle(e):
        act = e.pattern_match.group(1)
        config.set_pref(e.sender_id, "ai_enabled", (act == "تشغيل"))
        await e.edit(f"{'✅' if act == 'تشغيل' else '⛔'} تم {act} الذكاء")

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.عرض النماذج$"))
    async def ai_models(e):
        cur = config.get_pref(e.sender_id, "ai_model", "sonar")
        msg = "📊 النماذج المتاحة:\n" + "\n".join([f"`{m}` {'🟢' if m == cur else ''}" for m in config.AI_MODELS_LIST])
        await e.edit(msg)

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.تبديل النموذج\s+(.+)$"))
    async def ai_switch(e):
        m = e.pattern_match.group(1).strip()
        if m not in config.AI_MODELS_LIST: return await e.edit("❌ موديل غير موجود.")
        config.set_pref(e.sender_id, "ai_model", m)
        await e.edit(f"✅ تم التبديل إلى: `{m}`")

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.(ايقاف|تشغيل) هنا$"))
    async def ai_mute(e):
        act = e.pattern_match.group(1)
        cid = e.chat_id
        muted = config.get_pref(e.sender_id, "ai_muted_chats", [])
        if act == "ايقاف" and cid not in muted: muted.append(cid)
        elif act == "تشغيل" and cid in muted: muted.remove(cid)
        config.set_pref(e.sender_id, "ai_muted_chats", muted)
        await e.edit(f"{'🔕' if act == 'ايقاف' else '🔔'} تم {act} الذكاء هنا")

    @client.on(events.NewMessage(incoming=True))
    async def ai_reply(e):
        my_id = (await client.get_me()).id
        if not config.get_pref(my_id, "ai_enabled", False): return
        muted = config.get_pref(my_id, "ai_muted_chats", [])
        if e.chat_id in muted: return

        if e.is_private or e.mentioned or (e.is_reply and (await e.get_reply_message()).sender_id == my_id):
            sender = await e.get_sender()
            if sender and sender.bot: return
            if sender:
                config.track_last_messages(my_id, sender.id, e.raw_text or "")
            
            async with client.action(e.chat_id, 'typing'):
                model = config.get_pref(my_id, "ai_model", "sonar")
                resp = await config.get_ai_response(
                    e.raw_text or "",
                    model,
                    owner_id=my_id,
                    user_id=(sender.id if sender else None)
                )
                await e.reply(resp)

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.توليد\s+(.+)$"))
    async def ai_gen_img(e):
        prompt = e.pattern_match.group(1).strip()
        await e.edit(f"🎨 جاري توليد صورة لـ: {prompt} ...")
        my_id = (await client.get_me()).id
        current_model = config.get_pref(my_id, "ai_model", "polli-image-flux")
        if not current_model.startswith("polli-image"): current_model = "polli-image-flux"
        ok = await config.generate_image_polli(prompt, current_model, "polli_image.jpg")
        if not ok: return await e.edit("❌ فشل التوليد.")
        try:
            await client.send_file(e.chat_id, "polli_image.jpg", caption=f"🎨 `{prompt}`")
            await e.delete()
            os.remove("polli_image.jpg")
        except Exception as err: await e.edit(f"❌ خطأ: {err}")